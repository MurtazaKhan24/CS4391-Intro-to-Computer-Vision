# intro-to-computer-vision

### Installation
Install python packages
   ```Shell
   pip install -r requirement.txt
   ```
